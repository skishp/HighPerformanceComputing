#include "gemm.cpp"
extern "C" {
void
ulm_dgemm_(const char *transA, const char *transB,
const int *m, const int *n, const int *k, const double *alpha,
const double *A, const int *ldA, const double *B, const int *ldB,
const double *beta, double *C, const int *ldC)
{
// Call your C++ implementation.
// Do *not* allocate any memory within this wrapper.
    if(transA == "n" || transA == "N"){
        if(transB =="n" || transB == "N"){
            ulmblas::gemm(*m,*n,*k,*alpha,A,1,*ldA,B,1,*ldB,*beta,C,1,*ldC);
        }else{
            ulmblas::gemm(*m,*n,*k,*alpha,A,1,*ldA,B,*ldB,1,*beta,C,1,*ldC);
        }
    }else{
        if(transB == "n" || transB == "N"){
            ulmblas::gemm(*m,*n,*k,*alpha,A,*ldA,1,B,1,*ldB,*beta,C,1,*ldC);
        }else{
            ulmblas::gemm(*m,*n,*k,*alpha,A,*ldA,1,B,*ldB,1,*beta,C,1,*ldC);
        }
    }
}
} // extern "C