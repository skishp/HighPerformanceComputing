#include <cassert>
#include "gemv.hpp"
#include "matrix.hpp"
#include "vector.hpp"

// y \leftarrow \beta y + \alpha A x
void gemv(double alpha, const Matrix& A, const Vector& x,
      double beta, Vector& y) {
   // FIXME
}
