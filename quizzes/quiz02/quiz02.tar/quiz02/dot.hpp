#ifndef HPC_DOT_HPP
#define HPC_DOT_HPP

#include "vector.hpp"

double dot(const Vector& x, const Vector& y);

#endif
