#include <cassert>
#include <cstdlib>
#include "dot.hpp"
#include "vector.hpp"

double dot(const Vector& x, const Vector& y) {
   // FIXME
}
