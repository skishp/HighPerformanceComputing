#ifndef HPC_VECTOR_HPP
#define HPC_VECTOR_HPP

#include <cassert>
#include <cstdlib>

struct Vector {
   // FIXME
   Vector(std::size_t length)
      /* FIXME */
   {
   }

   ~Vector() {
      // FIXME
   }

   const double& operator()(std::size_t i) const {
      // FIXME
   }

   double& operator()(std::size_t i) {
      // FIXME
   }

   void init() {
      // FIXME
   }
};

#endif
